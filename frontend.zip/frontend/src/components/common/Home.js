import { useState, useEffect } from "react";
import Navbar from "../templates/Navbar";
import "./Home.css"
const Home = (props) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  // useEffect(() => {
  //   setName("Dass");
  // }, []);

  
  return(
  <div>
    <Navbar />
  <div  className="Home-screen" style={{
    textAlign:'center',
    fontSize:'30px',
    fontStyle:'revert',
    backgroundImage: 'url("https://static.wixstatic.com/media/238c0e_cd94f0c2cad74780b791314376f0644c~mv2.jpg/v1/fit/w_380,h_380,q_90/238c0e_cd94f0c2cad74780b791314376f0644c~mv2.jpg")',
    backgroundPosition: 'center', backgroundRepeat: "no-repeat"
  }}> 
  
  
     </div> 
     
     </div>
  )
};

export default Home;
